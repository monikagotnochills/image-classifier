def adjust_results4_isadog(results_dic, dogfile):
    """
    Adjusts the results dictionary to determine if classifier correctly 
    classified images 'as a dog' or 'not a dog'. Demonstrates if model
    architecture correctly classifies dog images even if it gets the
    dog breed wrong (not a match).

    Parameters:
      results_dic - Dictionary with 'key' as image filename and 'value' as a 
                    List. Where the list contains:
                    index 0 = pet image label (string)
                    index 1 = classifier label (string)
                    index 2 = 1/0 (int) where 1 = match between pet image
                              and classifier labels, 0 = no match between labels
                ---- indices 3 & 4 are added by this function ----
                 index 3 = 1/0 (int) where 1 = pet image 'is-a' dog and 
                          0 = pet image 'is-NOT-a' dog.
                 index 4 = 1/0 (int) where 1 = classifier label 'is-a' dog and
                          0 = classifier label 'is-NOT-a' dog.
      dogfile - Text file containing names of all dogs from both the pet image
                labels and classifier labels. One dog name per line in lowercase.
                If a breed has multiple names, they are separated by commas.
                (string - indicates text file's filename)

    Returns:
           None - results_dic is mutable data type so no return needed.
    """
    # Create dognames dictionary to quickly check if a label is a dog name
    dognames_dic = dict()

    # Read in dognames from the specified file
    with open(dogfile, "r") as infile:
        # Process each line in the file
        for line in infile:
            # Remove newline character and extra spaces
            dog_name = line.strip()

            # Add the dog name to dognames_dic if not already present
            if dog_name not in dognames_dic:
                dognames_dic[dog_name] = 1

    # Iterate over results_dic to add whether labels are 'of-a-dog' or not
    for key in results_dic:
        # Check if the pet image label is a dog
        is_pet_dog = 1 if results_dic[key][0] in dognames_dic else 0

        # Check if the classifier label is a dog
        is_classifier_dog = 1 if results_dic[key][1] in dognames_dic else 0

        # Append the results to the existing list for this key
        results_dic[key].extend([is_pet_dog, is_classifier_dog])